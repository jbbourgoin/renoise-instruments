Samsara Cycle Audio

VIRTUAL INSTRUMENTS AND EFFECTS

� Samsara Cycle Audio 2013

--------------


Install notes:

Copy to your VST folder and load in your DAW software.

--------------------------------------------------------

Visit the website and try the DEMO versions from the donators collections. Sets of many professional plug-ins made available after support of my work via a donation.

Once you make a donation.

You will receive links and downloads to new projects and updates.
These include previously unreleased projects as well as future projects.
Information about projects will be sent via email following donation.

Buying a license to one of my Low Cost plug-ins such as Murali - Ethnic Wind or VGP- Virtual Grand Piano or other set low price plug-in automatically qualifies for use of all the donator collection plug-ins as they become available.


----------------------------------------------------------------------


Please visit http://samcycle.blogspot.com for updates, news and new projects

If you would like to make any suggestions regarding the development of my projects, or send patch sets for others to use with our projects, then please send to:

samcaudio@gmail.com


------------------------------------------

Donation are always welcome in appreciation of my work :)

It is easy and secure to donate any amount to support us by clicking on the PayPal button at http://samcycle.blogspot.com or directly to our PayPal account: samcaudio@gmail.com

You don�t need a PayPal account to make a secure donation

THANK YOU AND ENJOY

NAMASTE